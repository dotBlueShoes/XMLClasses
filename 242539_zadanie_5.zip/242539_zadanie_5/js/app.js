const output = document.querySelector("#output");

let fileContent = null;

function refreshOutput() {
    output.innerHTML = normalize_markup(fileContent.innerHTML);
}

// ----
// Main
// ----

document.addEventListener("DOMContentLoaded", () => {
    fileInput.addEventListener("change", () => {
        handleFileInput();
        refreshOutput();
    });
    saveFileButton.addEventListener("click", handleSaveButton);
});
