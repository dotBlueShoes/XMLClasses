const employeeForm = document.querySelector("#employee_form");

const employeeButtons = { // To posses DOM buttons.
    add: employeeForm.querySelector(".btn_add"),
    modify: employeeForm.querySelector(".btn_modify"),
    delete: employeeForm.querySelector(".btn_delete"),
    submitButton: employeeForm.querySelector("input[type='submit']"),
};

const employeeFormFields = { // To get data from input DOM elements.
    id: employeeForm.querySelector("input[name='employee_id']"),
    name: employeeForm.querySelector("input[name='name']"),
    surname: employeeForm.querySelector("input[name='surname']"),
	personalId: employeeForm.querySelector("input[name='personalId']"),
	nation: employeeForm.querySelector("select[name='nation']"),
	dateOfBirth: employeeForm.querySelector("input[name='dateOfBirth']"),
	dateOfEmployment: employeeForm.querySelector("input[name='dateOfEmployment']"),
	shirtSize: employeeForm.querySelector("input[name='shirtSize']"),
	position: employeeForm.querySelector("select[name='position']"),
	desk: employeeForm.querySelector("input[name='desk']"),
	country: employeeForm.querySelector("input[name='country']"),
	city: employeeForm.querySelector("input[name='city']"),
	street: employeeForm.querySelector("input[name='street']"),
	stNumber: employeeForm.querySelector("input[name='number']"),
	zipCode: employeeForm.querySelector("input[name='zipCode']"),
	currency: employeeForm.querySelector("select[name='currency']"),
	beforeTax: employeeForm.querySelector("input[name='beforeTax']"),
	afterTax: employeeForm.querySelector("input[name='afterTax']"),
	isTemporary: employeeForm.querySelector("input[name='isTemporary']"),
	isSuspended: employeeForm.querySelector("input[name='isSuspended']"),
};

function showEmployeeFormFields() {
    const fields_div = employeeForm.querySelector(".form_fields");
    if (fields_div.classList.contains("hidden")) {
        fields_div.classList.remove("hidden");
    }
}

function hideEmployeeFormFields() {
    const fields_div = employeeForm.querySelector(".form_fields");
    if (!fields_div.classList.contains("hidden")) {
        fields_div.classList.add("hidden");
    }
}

function findEmployeeById(id) {
    let foundEmployee = null;
    fileContent.querySelectorAll("GameDevBusiness Employees Employee").forEach((employee) => {
        if (employee.getAttribute("id") === id) {
            foundEmployee = employee;
        }
    });
    return foundEmployee;
}

function createEmployeeElement() {
    const eployeeElement = element("Employee");
	
    eployeeElement.setAttribute("id", employeeFormFields.id.value);
	eployeeElement.setAttribute("position", employeeFormFields.position[employeeFormFields.position.selectedIndex].value);
	eployeeElement.setAttribute("ref-desk", employeeFormFields.desk.value);
	eployeeElement.setAttribute("isSuspended", employeeFormFields.isSuspended.value);
	
    eployeeElement.appendChild(element("Name", employeeFormFields.name.value));
    eployeeElement.appendChild(element("Surname", employeeFormFields.surname.value));
	
	const personalId = eployeeElement.appendChild(element("PersonalID", employeeFormFields.personalId.value));
	personalId.setAttribute("nation", employeeFormFields.nation[employeeFormFields.nation.selectedIndex].value);
	
	eployeeElement.appendChild(element("DateOfBirth", employeeFormFields.dateOfBirth.value));
	eployeeElement.appendChild(element("DateOfEmployment", employeeFormFields.dateOfEmployment.value));
	eployeeElement.appendChild(element("ShirtSize", employeeFormFields.shirtSize.value));
	
	const address = eployeeElement.appendChild(element("Address"));
	address.appendChild(element("Country", employeeFormFields.country.value));
	address.appendChild(element("City", employeeFormFields.city.value));
	address.appendChild(element("Street", employeeFormFields.street.value));
	address.appendChild(element("Number", employeeFormFields.stNumber.value));
	address.appendChild(element("ZIPCode", employeeFormFields.zipCode.value));
	
	const salary = eployeeElement.appendChild(element("Salary"));
	salary.setAttribute("currency", employeeFormFields.currency[employeeFormFields.currency.selectedIndex].value);
	salary.appendChild(element("BeforeTax", employeeFormFields.beforeTax.value));
	salary.appendChild(element("AfterTax", employeeFormFields.afterTax.value));
	
	if (employeeFormFields.isTemporary.value === "on")
		eployeeElement.appendChild(element("isTemporary"));

    return eployeeElement;
}

function modifyEmployeeById(id) {
    const employee = findEmployeeById(id);

    employee.querySelector("Name").textContent = employeeFormFields.name.value;
    employee.querySelector("Surname").textContent = employeeFormFields.surname.value;
	
	employee.setAttribute("position", employeeFormFields.position[employeeFormFields.position.selectedIndex].value);
	employee.setAttribute("ref-desk", employeeFormFields.desk.value);
	
	if (employeeFormFields.isSuspended.checked == true) {
		employee.setAttribute("isSuspended", "true");
	} else {
		const isSuspended = employee.getAttribute("isSuspended");
		if (isSuspended != null) {
			employee.removeAttribute("isSuspended");
		}
	}

	const personalId = employee.querySelector("PersonalID");
	personalId.textContent = employeeFormFields.personalId.value;
	personalId.setAttribute("nation", employeeFormFields.nation[employeeFormFields.nation.selectedIndex].value);
	
	employee.querySelector("DateOfBirth").textContent = employeeFormFields.dateOfBirth.value;
	employee.querySelector("DateOfEmployment").textContent = employeeFormFields.dateOfEmployment.value;
	
	const shirtSize = employeeFormFields.shirtSize.value;
	if (!isEmpty(shirtSize))
		employee.querySelector("ShirtSize").textContent = shirtSize;
	
	const address = employee.querySelector("Address");
	address.querySelector("Country").textContent = employeeFormFields.country.value;
	address.querySelector("City").textContent = employeeFormFields.city.value;
	address.querySelector("Street").textContent = employeeFormFields.street.value;
	address.querySelector("Number").textContent = employeeFormFields.stNumber.value;
	address.querySelector("ZIPCode").textContent = employeeFormFields.zipCode.value;

	const salary =  employee.querySelector("Salary");
	salary.setAttribute("currency", employeeFormFields.currency[employeeFormFields.currency.selectedIndex].value);
	salary.querySelector("BeforeTax").textContent = employeeFormFields.beforeTax.value;
	salary.querySelector("AfterTax").textContent = employeeFormFields.afterTax.value;
	
	if (employeeFormFields.isTemporary.checked == true) {
		const isTemporary = employee.querySelector("IsTemporary")
		if (isTemporary == null) {
			employee.appendChild(element("IsTemporary"));
		} 
	} else {
		const isTemporary = employee.querySelector("IsTemporary")
		if (isTemporary != null) {
			employee.removeChild(isTemporary);
		} 
	}
	
}

// --------------
// Event handlers
// --------------

employeeForm.addEventListener("submit", (action) => {
    action.preventDefault();
	
	if (!validate()) return;

    if (action.submitter.value === "Dodaj") { // ADD
        fileContent.querySelector("GameDevBusiness Employees").appendChild(createEmployeeElement());
    } else if (action.submitter.value === "Zapisz zmiany") { // MODIFY
        modifyEmployeeById(employeeFormFields.id.value);
    }

    refreshOutput();
});

employeeButtons.add.addEventListener("click", (action) => { // ADD BUTTON
    action.preventDefault();
	
    // Check whether ID exist and if is valid.
    const id = employeeFormFields.id.value;
	if (isID(id)) {
		if (isFileLoaded()) {
			const employee = findEmployeeById(id);
		
			if (employee) {
				alert("ID is already used");
				return;
			}
		
			employeeForm.reset();
			employeeFormFields.id.value = id;
			employeeButtons.submitButton.value = "Dodaj";
			
			showEmployeeFormFields(); // Show form fields.
			refreshOutput(); // Modify employee in UI and FILE.
		} else printErrorNoFile();
	} else printErrorID();
	
});


employeeButtons.modify.addEventListener("click", (action) => { // MODIFY BUTTON
    action.preventDefault();

	// Check whether ID exist and if is valid.
    const id = employeeFormFields.id.value;
	if (isID(id)) {
		if (isFileLoaded()) {
			const employee = findEmployeeById(id);
		
			if (!employee) {
				alert("Employee does not exsist!");
				return;
			}
		
			employeeButtons.submitButton.value = "Zapisz zmiany";
			employeeFormFields.name.value = employee.querySelector("Name").textContent;
			employeeFormFields.surname.value = employee.querySelector("Surname").textContent;
			
			if (employee.getAttribute("position") === "Programmer")
				employeeFormFields.position.selectedIndex = 0;
			else if (employee.getAttribute("position") === "Desiner")
				employeeFormFields.position.selectedIndex = 1;
			else if (employee.getAttribute("position") === "Level-Designer")
				employeeFormFields.position.selectedIndex = 2;
			
			employeeFormFields.desk.value = employee.getAttribute("ref-desk");
			
			const isSuspended = employee.getAttribute('isSuspended');
			if (isSuspended != null)
				employeeFormFields.isSuspended.checked = true;
			
			const personalId = employee.querySelector("PersonalID");
			employeeFormFields.personalId.value = personalId.textContent;
			
			if (employee.getAttribute("nation") === "Poland")
				employeeFormFields.nation.selectedIndex = 0;
			else if (employee.getAttribute("nation") === "UK")
				employeeFormFields.nation.selectedIndex = 1;
			else if (employee.getAttribute("nation") === "Germany")
				employeeFormFields.nation.selectedIndex = 2;
		
			employeeFormFields.dateOfBirth.value = employee.querySelector("DateOfBirth").textContent;
			employeeFormFields.dateOfEmployment.value = employee.querySelector("DateOfEmployment").textContent;
			
			const shirtSize = employee.querySelector("ShirtSize");
			if (shirtSize != null)
				employeeFormFields.shirtSize.value = shirtSize.textContent;
			
			const address = employee.querySelector("Address");
			
			employeeFormFields.country.value = address.querySelector("Country").textContent;
			employeeFormFields.city.value = address.querySelector("City").textContent;
			employeeFormFields.street.value = address.querySelector("Street").textContent;
			employeeFormFields.stNumber.value = address.querySelector("Number").textContent;
			employeeFormFields.zipCode.value = address.querySelector("ZIPCode").textContent;
			
			const salary =  employee.querySelector("Salary");
			
			if (employee.getAttribute("currency") === "PLN")
				employeeFormFields.currency.selectedIndex = 0;
			else if (employee.getAttribute("currency") === "EUR")
				employeeFormFields.currency.selectedIndex = 1;
			
			employeeFormFields.currency.value = salary.getAttribute("currency");
			employeeFormFields.beforeTax.value = salary.querySelector("BeforeTax").textContent;
			employeeFormFields.afterTax.value = salary.querySelector("AfterTax").textContent;
			
			const isTemporary = employee.querySelector("IsTemporary");
			if (isTemporary != null)
				employeeFormFields.isTemporary.checked = true;
		
			showEmployeeFormFields(); // Show form fields.
			refreshOutput(); // Modify employee in UI and FILE.
		} else printErrorNoFile();
	} else printErrorID();
	
});

employeeButtons.delete.addEventListener("click", (action) => { // DELETE BUTTON
	action.preventDefault();
	
	// Check whether ID exist and if is valid.
    const id = employeeFormFields.id.value;
	if (isID(id)) {
		if (isFileLoaded()) {
			const employee = findEmployeeById(id);
		
			if (!employee) {
				alert("Employee does not exsist!");
				return;
			}
		
			employee.remove();
			hideEmployeeFormFields();
			refreshOutput(); // Modify employee in UI and FILE.
		
			alert(`Deleted employee ID ${id}`);
		} else printErrorNoFile();
	} else printErrorID();
	
});
