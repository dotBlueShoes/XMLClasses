// -------------
// File handling
// -------------

const fileInput = document.getElementById("fileInput");
const saveFileButton = document.getElementById("saveFileButton");

function printErrorNoFile() {
	alert("XML File was not loaded!");
}

function isFileLoaded() {
	if (fileContent == null)
		return false;
	return true;
}

function handleFileInput() {
    const [file] = fileInput.files;

    const url = URL.createObjectURL(file);
    const xhr = new XMLHttpRequest();
    xhr.open("GET", url, false);
    xhr.setRequestHeader("Content-Type", "text/xml");
    xhr.send(null);

    const xmlDoc = xhr.responseXML;
    fileContent = xmlDoc.children[0]; // Main Node
}

function handleSaveButton() {
	
	if (!isFileLoaded()) {
        printErrorNoFile();
		return;
    }

    const serializer = new XMLSerializer();
    const serializedString = serializer.serializeToString(fileContent);

    // Create temp file
    const blob = new Blob([serializedString], { type: "text/xml" });

	// Create vir element with link
    const aElement = document.createElement("a");
    aElement.href = URL.createObjectURL(blob);
    aElement.download = "generatedCode.xml";
    aElement.click();
}
