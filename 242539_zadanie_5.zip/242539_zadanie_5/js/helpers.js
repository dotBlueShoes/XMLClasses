function element(name, textContent) {
    const el = document.createElementNS("", name);
    textContent && (el.textContent = textContent);
    return el;
}
