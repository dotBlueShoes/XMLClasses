const replace_special_chars = (str) => {
    return str
        .replace(/&/g, "&amp;")
        .replace(/>/g, "&gt;")
        .replace(/</g, "&lt;")
        .replace(/"/g, "&quot;");
};

const delete_indent = (str) => {
    const indent = "                        ";
    return str.replaceAll(indent, "");
};

// Logic for data representation inside XML file.
const normalize_markup = (script_str) => {
    script_str = replace_special_chars(script_str);
    script_str = delete_indent(script_str);

    return script_str;
};

