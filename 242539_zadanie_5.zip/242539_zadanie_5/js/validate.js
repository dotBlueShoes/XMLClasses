
// HELPERS

function isEmpty(str) {
	if (str == null || str.trim().length == 0)
			return true;
	return false;
}

// PRINTERS

const TEXT_INVALID = "is invalid!";

function printErrorID() {
	alert("ID " + TEXT_INVALID);
}

// VALIDATION

function isID(id) {
	const ID_MIN = 0;
	const ID_MAX = 1000000;
	
	if (isEmpty(id) || parseInt(id) < ID_MIN || parseInt(id) > ID_MAX)
		return false;
	return true;
}

function isBigLetterStringExtra(data) {
	const expression = "[A-Z0-9]([A-Za-z.+0-9\s])*";
	
	if (isEmpty(data) || !data.match(expression))
		return false;
	return true;
}

function isBigLetterString(data) {
	const expression = "[A-Z]([a-z])*";
	
	if (isEmpty(data) || !data.match(expression))
		return false;
	return true;
}

function isPersonalID(data) {
	const expression = "[0-9]{11}";
	
	if (isEmpty(data) || !data.match(expression))
		return false;
	return true;
}

function isDate(data) {
	const expression = "[0-9]{4}-[0-9]{2}-[0-9]{2}";
	
	if (isEmpty(data) || !data.match(expression))
		return false;
	return true;
}

function isShirtSize(data) {
	if (isEmpty(data))
		return false;
	if (parseInt(data) > 0)
		return true;
	if (data === "small")
		return true;
	else if (data === "medium")
		return true;
	else if (data === "large")
		return true;
	return false;
}

function isZIPCode(data) {
	const expression = "[0-9][0-9][-][0-9][0-9][0-9]";
	
	if (isEmpty(data) || !data.match(expression))
		return false;
	return true;
}
	
function isSalary(data) {
	const ID_MIN = 0.00;
	const ID_MAX = 1000000.99;
	
	if (isEmpty(data) || parseFloat(data).toFixed(2) < ID_MIN || parseFloat(data).toFixed(2) > ID_MAX)
		return false;
	return true;
}

function isPointingToExsistingDesk(id, ids, idsLength) {
	// simply check whether id === ids[0] ... ids[length];
	return true;
}

function validate() {
	
	let output = "";
	
	// NAME
    if (!isBigLetterString(employeeFormFields.name.value)) {
		const name = "name";
		output += name + " " + TEXT_INVALID;
	}
	
	// SURNAME
    if (!isBigLetterString(employeeFormFields.surname.value)) {
		const name = "surname";
		output += name + " " + TEXT_INVALID;
	}
	
	// PERSONAL_ID
	if (!isPersonalID(employeeFormFields.personalId.value)) {
		const name = "personalId";
		output += name + " " + TEXT_INVALID;
	}
	
	//// NATION
	//if (isEmpty(employeeFormFields.nation.value)) {
	//	const name = "nation";
	//	output += name + " " + TEXT_INVALID;
	//}
	
	// DATE_OF_BIRTH
	if (!isDate(employeeFormFields.dateOfBirth.value)) {
		const name = "dateOfBirth";
		output += name + " " + TEXT_INVALID;
	}
	
	// DATE_OF_EMPLOYMENNT
	if (!isDate(employeeFormFields.dateOfEmployment.value)) {
		const name = "dateOfEmployment";
		output += name + " " + TEXT_INVALID;
	}
	
	// SHIRT_SIZE
	if (!isShirtSize(employeeFormFields.shirtSize.value)) {
		const name = "shirtSize";
		output += name + " " + TEXT_INVALID;
	}
	
	//// POSITION
	//if (isEmpty(employeeFormFields.position.value)) {
	//	const name = "position";
	//	output += name + " " + TEXT_INVALID;
	//}
	
	// DESK
	if (!isID(employeeFormFields.desk.value) && !isPointingToExsistingDesk(0, 0, 0)) {
		const name = "desk";
		output += name + " " + TEXT_INVALID;
	}
	
	// COUNTRY
	if (isEmpty(employeeFormFields.country.value)) {
		const name = "country";
		output += name + " " + TEXT_INVALID;
	}
	
	// CITY
	if (!isBigLetterString(employeeFormFields.city.value)) {
		const name = "city";
		output += name + " " + TEXT_INVALID;
	}
	
	// STREET
	if (!isBigLetterString(employeeFormFields.street.value)) {
		const name = "street";
		output += name + " " + TEXT_INVALID;
	}
	
	// STREET_NUMBER
	if (isEmpty(employeeFormFields.stNumber.value)) {
		const name = "stNumber";
		output += name + " " + TEXT_INVALID;
	}
	
	// ZIP_CODE
	if (!isZIPCode(employeeFormFields.zipCode.value)) {
		const name = "zipCode";
		output += name + " " + TEXT_INVALID;
	}
	
	//// CURRENCY
	//if (isEmpty(employeeFormFields.currency.value)) {
	//	const name = "currency";
	//	output += name + " cannot be empty\n";
	//}
	
	// BEFORE_TAX
	if (!isSalary(employeeFormFields.beforeTax.value)) {
		const name = "beforeTax";
		output += name + " " + TEXT_INVALID;
	}
	
	// AFTER_TAX
	if (!isSalary(employeeFormFields.afterTax.value)) {
		const name = "afterTax";
		output += name + " " + TEXT_INVALID;
	}
	
	//// IS_TEMPORARY
	//if (isEmpty(employeeFormFields.isTemporary.value)) {
	//	const name = "isTemporary";
	//	output += name + " cannot be empty\n";
	//}
	//
	//// IS_SUSPENDED
	//if (isEmpty(employeeFormFields.isSuspended.value)) {
	//	const name = "isSuspended";
	//	output += name + " cannot be empty\n";
	//}
	
	if (!isEmpty(output)) {
		alert(output);
		return false;
	}
	
	return true;
}