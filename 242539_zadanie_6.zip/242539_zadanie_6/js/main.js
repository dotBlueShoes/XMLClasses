
// BUTTONS ONCLICKs

function onExercise6Click() {
	document.getElementById("secret").style.visibility = "visible";
}